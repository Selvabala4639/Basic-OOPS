﻿using System; 
using System.Collections.Generic;
namespace PayrollManagement;

class Program
{


    public static void Main(string[] args)
    {
        
        Operations.AddingDefaultDate();
        Operations.MainMenu();
    }

    
}