﻿using System;
using System.Collections.Generic;
namespace OnlineLibraryManagement;
class Program
{
    public static void Main(string[] args)
    {
        Operations.AddingDefaultData();
        Operations.MainMneu();
    }
}