using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayrollManagement
{
    public static class Operations
    {
         
    }

    public static void AddingDefaultDate()
    {
        EmployeeDetails employee= new EmployeeDetails("Ravi"	,new DateTime(1999,11,11)	,9958858888	,Gender.Male,	Branch.Eymard,	Team.Developer);
    }
}