using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayrollManagement
{
    public class AttendenceDetails
    {
        private static int s_attendenceId=1000;
        public string AttendenceId { get; }
        public string EmployeeID { get; set; }
        public DateTime Date { get; set; }
        public DateTime CheckInTime { get; set; }
        public DateTime CheckOutTime { get; set; }
        public int HoursWorked { get; set; }

        public AttendenceDetails(string id, DateTime date, DateTime checkin, DateTime checkout, int hoursWorked)
        {
            s_attendenceId++;
            AttendenceId = "AID"+s_attendenceId;
            EmployeeID= id;
            Date =date;
            CheckInTime= checkin;
            CheckOutTime= checkout;
            HoursWorked= hoursWorked;
        }
    }
}